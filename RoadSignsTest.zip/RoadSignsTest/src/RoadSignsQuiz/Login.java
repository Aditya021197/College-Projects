
package RoadSignsQuiz;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Login extends javax.swing.JFrame {
 static ResourceBundle rBundle = ResourceBundle.getBundle("rbundles/ResourceBundle");
  Locale[] loc = {new Locale("en", "GB"), new Locale("es","ES"), new Locale("ja", "JP")};
  
  
  Connection conn = null;
PreparedStatement ps = null;
ResultSet rs = null;

    public Login() {
        initComponents();
        changeLang(loc[0]);
    }

       public Connection getConnection(){
        Connection conn;
        
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost/myjdbcexamples", "root", "");//Gets the database connection path
            return conn;
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
    }
       
       
           public void executeSQLQuery(String query, String notice)
    {
         try {
             Connection conn = getConnection();
             Statement st;
             st = conn.createStatement();
             try {
                 if((st.executeUpdate(query)) == 1)
                 {
                     JOptionPane.showMessageDialog(null, " Data " + notice + " successfully ");
                 }
                 
                 else{
                     JOptionPane.showMessageDialog(null, " Query Failed ");
                 }    } catch (SQLException ex) {
                     Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
                 }
             
         } catch (SQLException ex) {
             Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
         }


    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        languageSelection = new javax.swing.ButtonGroup();
        chooseLangLabel = new javax.swing.JLabel();
        loginBtn = new javax.swing.JButton();
        usernameLbl = new javax.swing.JLabel();
        pwLbl = new javax.swing.JLabel();
        passwordField = new javax.swing.JPasswordField();
        usernameTf = new javax.swing.JTextField();
        instructLbl = new javax.swing.JLabel();
        exitBtn = new javax.swing.JButton();
        rsaLabel = new javax.swing.JLabel();
        signUpLbl = new javax.swing.JLabel();
        englishBtn = new javax.swing.JToggleButton();
        spanishBtn = new javax.swing.JToggleButton();
        japaneseBtn = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        chooseLangLabel.setText("Please Choose Your Language:");

        loginBtn.setText("Login");
        loginBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginBtnActionPerformed(evt);
            }
        });

        usernameLbl.setText("Username:");

        pwLbl.setText("Password:");

        instructLbl.setText("Login entering your details or if you don't have an account with us, Register by clicking the link below");

        exitBtn.setText("Exit");
        exitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitBtnActionPerformed(evt);
            }
        });

        rsaLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RoadSignsQuiz/RSALogo.jpg"))); // NOI18N

        signUpLbl.setForeground(new java.awt.Color(51, 51, 255));
        signUpLbl.setText("Click here to register");
        signUpLbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                signUpLblMouseClicked(evt);
            }
        });

        languageSelection.add(englishBtn);
        englishBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RoadSignsQuiz/english.png"))); // NOI18N
        englishBtn.setText("English");
        englishBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                englishBtnActionPerformed(evt);
            }
        });

        languageSelection.add(spanishBtn);
        spanishBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RoadSignsQuiz/spanish.png"))); // NOI18N
        spanishBtn.setText("Spanish");
        spanishBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                spanishBtnActionPerformed(evt);
            }
        });

        languageSelection.add(japaneseBtn);
        japaneseBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RoadSignsQuiz/japanese.jpg"))); // NOI18N
        japaneseBtn.setText("Japanese");
        japaneseBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                japaneseBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(266, 266, 266)
                        .addComponent(chooseLangLabel))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(156, 156, 156)
                        .addComponent(englishBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(spanishBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(japaneseBtn))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(81, 81, 81)
                        .addComponent(instructLbl)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(rsaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 99, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(signUpLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(loginBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(exitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(pwLbl)
                            .addComponent(usernameLbl))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(usernameTf, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)))
                .addGap(304, 304, 304))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(chooseLangLabel)
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(englishBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(spanishBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(japaneseBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(instructLbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(signUpLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(usernameTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(usernameLbl))
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pwLbl)))
                    .addComponent(rsaLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(loginBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(exitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void loginBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginBtnActionPerformed
             conn = DatabaseConnector.ConnectDatabase();
        
        String query = "SELECT * FROM roadtestusers WHERE username =? AND password =? ";
        
        try{
            ps = conn.prepareStatement(query);
            ps.setString(1,usernameTf.getText());
            ps.setString(2,passwordField.getText());
            rs = ps.executeQuery();
            
            if(rs.next()){//If the user exists in the database
                
            if(englishBtn.isSelected()){
            JOptionPane.showMessageDialog(null, rBundle.getString("loginSuccess"), rBundle.getString("successT"), JOptionPane.INFORMATION_MESSAGE);
            this.setVisible(false);
            String user = usernameTf.getText();
            new BeforeTest(user, loc[0]).setVisible(true);
            }
                
            if(spanishBtn.isSelected()){
            JOptionPane.showMessageDialog(null, rBundle.getString("loginSuccess"), rBundle.getString("successT"), JOptionPane.INFORMATION_MESSAGE);
            this.setVisible(false);
            String user = usernameTf.getText();
            new BeforeTest(user, loc[1]).setVisible(true);
            }
            
            if(japaneseBtn.isSelected()){
            JOptionPane.showMessageDialog(null, rBundle.getString("loginSuccess"), rBundle.getString("successT"), JOptionPane.INFORMATION_MESSAGE);
            this.setVisible(false);
            String user = usernameTf.getText();
            new BeforeTest(user, loc[2]).setVisible(true);
            }
            
       }
            
         
            
            else{
                JOptionPane.showMessageDialog(null, rBundle.getString("loginFailed"), rBundle.getString("errorT"), JOptionPane.ERROR_MESSAGE);
            }
            
        }catch(SQLException | NullPointerException e){
            JOptionPane.showMessageDialog(null, rBundle.getString("disconnected"), rBundle.getString("errorT"), JOptionPane.ERROR_MESSAGE);
        }
        
        
        
    }//GEN-LAST:event_loginBtnActionPerformed

    private void exitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitBtnActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitBtnActionPerformed

    private void signUpLblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signUpLblMouseClicked
        register reg = new register();
        this.setVisible(false);
        reg.setVisible(true);
    }//GEN-LAST:event_signUpLblMouseClicked

    private void englishBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_englishBtnActionPerformed
        changeLang(loc[0]);
    }//GEN-LAST:event_englishBtnActionPerformed

    private void spanishBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_spanishBtnActionPerformed
         changeLang(loc[1]);
    }//GEN-LAST:event_spanishBtnActionPerformed

    private void japaneseBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_japaneseBtnActionPerformed
         changeLang(loc[2]);
    }//GEN-LAST:event_japaneseBtnActionPerformed

    private void changeLang(Locale loc){
 rBundle = ResourceBundle.getBundle("rbundles/ResourceBundle", loc);
 chooseLangLabel.setText(rBundle.getString("chooseLangLabel"));
 usernameLbl.setText(rBundle.getString("usernameLbl"));
 pwLbl.setText(rBundle.getString("pwLbl"));
 englishBtn.setText(rBundle.getString("englishBtn"));
 spanishBtn.setText(rBundle.getString("spanishBtn"));
 japaneseBtn.setText(rBundle.getString("japaneseBtn"));
 loginBtn.setText(rBundle.getString("loginBtn"));
 instructLbl.setText(rBundle.getString("instructLbl"));
 signUpLbl.setText(rBundle.getString("signUpBtn"));
 exitBtn.setText(rBundle.getString("exitBtn"));
 setTitle(rBundle.getString("loginTitle"));
 
 }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(false);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel chooseLangLabel;
    private javax.swing.JToggleButton englishBtn;
    private javax.swing.JButton exitBtn;
    private javax.swing.JLabel instructLbl;
    private javax.swing.JToggleButton japaneseBtn;
    private javax.swing.ButtonGroup languageSelection;
    private javax.swing.JButton loginBtn;
    private javax.swing.JPasswordField passwordField;
    private javax.swing.JLabel pwLbl;
    private javax.swing.JLabel rsaLabel;
    private javax.swing.JLabel signUpLbl;
    private javax.swing.JToggleButton spanishBtn;
    private javax.swing.JLabel usernameLbl;
    private javax.swing.JTextField usernameTf;
    // End of variables declaration//GEN-END:variables
}
