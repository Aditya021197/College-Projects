package RoadSignsQuiz;

import java.awt.geom.RoundRectangle2D;
import javax.swing.JLabel;
import javax.swing.JProgressBar;


public class splashWelcome extends javax.swing.JFrame {

RoundRectangle2D roundRect;
    public splashWelcome() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        splashPanel = new javax.swing.JPanel();
        rsaTitleSpanish = new javax.swing.JLabel();
        rsaLabel = new javax.swing.JLabel();
        loadingMeter = new javax.swing.JProgressBar();
        rsaTitleEnglish = new javax.swing.JLabel();
        rsaTitleJapanese = new javax.swing.JLabel();
        loadingProgress = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        splashPanel.setBackground(new java.awt.Color(51, 153, 255));
        splashPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        splashPanel.setForeground(new java.awt.Color(255, 0, 0));

        rsaTitleSpanish.setBackground(new java.awt.Color(255, 0, 0));
        rsaTitleSpanish.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        rsaTitleSpanish.setForeground(new java.awt.Color(255, 255, 255));
        rsaTitleSpanish.setText(" Examen de señales de carretera");

        rsaLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RoadSignsQuiz/RSALogo.jpg"))); // NOI18N

        loadingMeter.setForeground(new java.awt.Color(0, 0, 0));

        rsaTitleEnglish.setBackground(new java.awt.Color(255, 0, 0));
        rsaTitleEnglish.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        rsaTitleEnglish.setForeground(new java.awt.Color(255, 255, 255));
        rsaTitleEnglish.setText(" Road Signs Test");

        rsaTitleJapanese.setBackground(new java.awt.Color(255, 0, 0));
        rsaTitleJapanese.setForeground(new java.awt.Color(255, 255, 255));
        rsaTitleJapanese.setText("道路標識試験");

        loadingProgress.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        loadingProgress.setForeground(new java.awt.Color(255, 255, 255));
        loadingProgress.setText("0%");

        javax.swing.GroupLayout splashPanelLayout = new javax.swing.GroupLayout(splashPanel);
        splashPanel.setLayout(splashPanelLayout);
        splashPanelLayout.setHorizontalGroup(
            splashPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, splashPanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(rsaTitleSpanish, javax.swing.GroupLayout.PREFERRED_SIZE, 394, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(95, 95, 95))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, splashPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(splashPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, splashPanelLayout.createSequentialGroup()
                        .addComponent(rsaTitleEnglish, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(155, 155, 155))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, splashPanelLayout.createSequentialGroup()
                        .addComponent(rsaTitleJapanese)
                        .addGap(287, 287, 287))))
            .addGroup(splashPanelLayout.createSequentialGroup()
                .addGroup(splashPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(splashPanelLayout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(loadingMeter, javax.swing.GroupLayout.PREFERRED_SIZE, 568, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(splashPanelLayout.createSequentialGroup()
                        .addGap(230, 230, 230)
                        .addComponent(rsaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(splashPanelLayout.createSequentialGroup()
                .addGap(265, 265, 265)
                .addComponent(loadingProgress, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        splashPanelLayout.setVerticalGroup(
            splashPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(splashPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(rsaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rsaTitleEnglish)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(rsaTitleSpanish)
                .addGap(18, 18, 18)
                .addComponent(rsaTitleJapanese)
                .addGap(23, 23, 23)
                .addComponent(loadingProgress, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(loadingMeter, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(splashPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(splashPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

 
    public static void main(String args[]) {
       
      
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(splashWelcome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(splashWelcome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(splashWelcome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(splashWelcome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new splashWelcome().setVisible(false);
            }
        });
    }
    
    public JLabel getLoadingProgress(){
    return loadingProgress;//Returns the loading progress percentage to the splash screen
    }
    
     public JProgressBar getLoadingMeter(){
    return loadingMeter; //Returns the loading meter to the splash screen
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JProgressBar loadingMeter;
    private javax.swing.JLabel loadingProgress;
    private javax.swing.JLabel rsaLabel;
    private javax.swing.JLabel rsaTitleEnglish;
    private javax.swing.JLabel rsaTitleJapanese;
    private javax.swing.JLabel rsaTitleSpanish;
    private javax.swing.JPanel splashPanel;
    // End of variables declaration//GEN-END:variables
}
