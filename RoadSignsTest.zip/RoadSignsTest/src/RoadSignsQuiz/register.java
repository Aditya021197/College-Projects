/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RoadSignsQuiz;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author K00206241
 */
public class register extends javax.swing.JFrame {

  static ResourceBundle rBundle = ResourceBundle.getBundle("rbundles/ResourceBundle");
  Locale[] loc = {new Locale("en", "GB"), new Locale("es","ES"), new Locale("ja", "JP")};
  
    public register() {
        initComponents();
    }

          public Connection getConnection(){
        Connection conn;
        
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost/roadsigntest", "root", "");
            return conn;
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
    }
          
          
          
                 public void executeSQLQuery(String query, String notice)
    {
         try {
             Connection conn = getConnection();
             Statement st;
             st = conn.createStatement();
             try {
                 if((st.executeUpdate(query)) == 1)
                 {
                     JOptionPane.showMessageDialog(null,  notice, rBundle.getString("successT"), JOptionPane.PLAIN_MESSAGE );
                 }
                 
                 else{
                     JOptionPane.showMessageDialog(null, " Query Failed ");
                 }    } catch (SQLException ex) {
                     Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
                 }
             
         } catch (SQLException ex) {
             Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
         }

}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        regBtn = new javax.swing.JButton();
        fullNameLbl = new javax.swing.JLabel();
        usernameLbl = new javax.swing.JLabel();
        pwLbl = new javax.swing.JLabel();
        fullnameTf = new javax.swing.JTextField();
        usernameTf = new javax.swing.JTextField();
        chooseLangLabel = new javax.swing.JLabel();
        englishBtn = new javax.swing.JButton();
        spanishBtn = new javax.swing.JButton();
        japaneseBtn = new javax.swing.JButton();
        passwordField = new javax.swing.JPasswordField();
        exitBtn = new javax.swing.JButton();
        rsaLabel = new javax.swing.JLabel();
        loginFormLink = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Register to take your test");

        regBtn.setText("Register");
        regBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regBtnActionPerformed(evt);
            }
        });

        fullNameLbl.setText("Full Name:");

        usernameLbl.setText("Username:");

        pwLbl.setText("Password:");

        chooseLangLabel.setText("Please Choose Your Language:");

        englishBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RoadSignsQuiz/english.png"))); // NOI18N
        englishBtn.setText("English");
        englishBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                englishBtnActionPerformed(evt);
            }
        });

        spanishBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RoadSignsQuiz/spanish.png"))); // NOI18N
        spanishBtn.setText("Spanish");
        spanishBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                spanishBtnActionPerformed(evt);
            }
        });

        japaneseBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RoadSignsQuiz/japanese.jpg"))); // NOI18N
        japaneseBtn.setText("Japanese");
        japaneseBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                japaneseBtnActionPerformed(evt);
            }
        });

        exitBtn.setText("Exit");
        exitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitBtnActionPerformed(evt);
            }
        });

        rsaLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RoadSignsQuiz/RSALogo.jpg"))); // NOI18N

        loginFormLink.setForeground(new java.awt.Color(51, 51, 255));
        loginFormLink.setText("If you have an account with us, click here to login");
        loginFormLink.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                loginFormLinkMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addComponent(rsaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(fullNameLbl)
                            .addComponent(usernameLbl)
                            .addComponent(pwLbl))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(usernameTf, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(passwordField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(fullnameTf, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(146, 146, 146)
                        .addComponent(regBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(exitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(127, 127, 127)
                        .addComponent(englishBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(spanishBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(japaneseBtn)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(222, 222, 222)
                        .addComponent(chooseLangLabel))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(loginFormLink, javax.swing.GroupLayout.PREFERRED_SIZE, 579, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 29, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(chooseLangLabel)
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(englishBtn)
                    .addComponent(spanishBtn)
                    .addComponent(japaneseBtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(loginFormLink)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(fullnameTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(fullNameLbl))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(usernameLbl)
                            .addComponent(usernameTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(pwLbl)
                            .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(rsaLabel)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(exitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(regBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void englishBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_englishBtnActionPerformed
       changeLang(loc[0]);
    }//GEN-LAST:event_englishBtnActionPerformed

    private void spanishBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_spanishBtnActionPerformed
        changeLang(loc[1]);
    }//GEN-LAST:event_spanishBtnActionPerformed

    private void japaneseBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_japaneseBtnActionPerformed
        changeLang(loc[2]);
    }//GEN-LAST:event_japaneseBtnActionPerformed

    private void regBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regBtnActionPerformed
        if(fullnameTf.getText().equals("") || usernameTf.getText().equals("") || passwordField.getText().equals("")){
        JOptionPane.showMessageDialog(null, rBundle.getString("fillInReg"), rBundle.getString("errorT"), JOptionPane.ERROR_MESSAGE);
        }
        else{
        String query = "INSERT INTO roadtestusers(fullname, username, password)VALUES('"+fullnameTf.getText()+"','"+usernameTf.getText()+"','"+passwordField.getText()+"')";
        executeSQLQuery(query, rBundle.getString("registered"));
        
        fullnameTf.setText("");
        usernameTf.setText("");
        passwordField.setText("");
        
        Login log = new Login();
        this.setVisible(false);
        log.setVisible(true);
        }
    }//GEN-LAST:event_regBtnActionPerformed

    private void exitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitBtnActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitBtnActionPerformed

    private void loginFormLinkMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loginFormLinkMouseClicked
        Login login = new Login();
        this.setVisible(false);
        login.setVisible(true);
    }//GEN-LAST:event_loginFormLinkMouseClicked

 private void changeLang(Locale loc){
 rBundle = ResourceBundle.getBundle("rbundles/ResourceBundle", loc);
 chooseLangLabel.setText(rBundle.getString("chooseLangLabel"));
 regBtn.setText(rBundle.getString("regBtn"));
 fullNameLbl.setText(rBundle.getString("fullNameLbl"));
 usernameLbl.setText(rBundle.getString("usernameLbl"));
 pwLbl.setText(rBundle.getString("pwLbl"));
 englishBtn.setText(rBundle.getString("englishBtn"));
 spanishBtn.setText(rBundle.getString("spanishBtn"));
 japaneseBtn.setText(rBundle.getString("japaneseBtn"));
 exitBtn.setText(rBundle.getString("exitBtn"));
 loginFormLink.setText(rBundle.getString("loginNavBtn"));
 setTitle(rBundle.getString("title"));
 }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new register().setVisible(false);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel chooseLangLabel;
    private javax.swing.JButton englishBtn;
    private javax.swing.JButton exitBtn;
    private javax.swing.JLabel fullNameLbl;
    private javax.swing.JTextField fullnameTf;
    private javax.swing.JButton japaneseBtn;
    private javax.swing.JLabel loginFormLink;
    private javax.swing.JPasswordField passwordField;
    private javax.swing.JLabel pwLbl;
    private javax.swing.JButton regBtn;
    private javax.swing.JLabel rsaLabel;
    private javax.swing.JButton spanishBtn;
    private javax.swing.JLabel usernameLbl;
    private javax.swing.JTextField usernameTf;
    // End of variables declaration//GEN-END:variables
}
