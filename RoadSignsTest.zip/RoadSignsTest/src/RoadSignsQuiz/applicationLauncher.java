package RoadSignsQuiz;

public class applicationLauncher {
    public static void main(String[] args) {
    splashWelcome sw = new splashWelcome();//Creates an object for the splash screen
    Login login = new Login();//Creates an object for the login form
    sw.setVisible(true);//Launches the splash window when the program runs
    try{
     for(int i = 0; i <= 100; i++){//loops through the progress counter
     Thread.sleep(100);//Speed of the loading meter
     sw.getLoadingProgress().setText(Integer.toString(i) + "%");//Displays the loading percentage
     sw.getLoadingMeter().setValue(i);//Displays the loading progress meter
     
     if(i == 100){//If loading progress is 100%
     sw.setVisible(false);//Splash screen disappears
     login.setVisible(true);//Login form appears
     }
     
    }
    }catch(InterruptedException iex){
    System.out.println(iex.getMessage());
    }
       
}
}
