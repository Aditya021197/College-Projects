package RoadSignsQuiz;

import java.sql.*;
import javax.swing.*;



public class DatabaseConnector {
    Connection conn = null;
    public static Connection ConnectDatabase(){
    try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/roadsigntest", "root", "");
        //JOptionPane.showMessageDialog(null, "Login Success");
        return conn;
    }
    catch(Exception e){
        JOptionPane.showMessageDialog(null, "" + e);
        return null;
    }
    }
    
}
