package RoadSignsQuiz;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;



public class BeforeTest extends javax.swing.JFrame {

static ResourceBundle resBundle = ResourceBundle.getBundle("rbundles/ResourceBundle");
Locale[] loc = {new Locale("en", "GB"), new Locale("es", "ES"), new Locale("ja", "JP")};

Connection conn = null;
PreparedStatement ps = null;
ResultSet rs = null;

    public BeforeTest() {
        initComponents();
    }
    
    public BeforeTest(String username){
        initComponents();
        changeLang(loc[0]);
        scoreHistoryTable.setEnabled(false);
    welcomeLabel.setText(resBundle.getString("welcomeLabel"));
    nameLabel.setText(username);
    String name = nameLabel.getText();
      conn = DatabaseConnector.ConnectDatabase();
    String query = "SELECT * FROM roadtestscores WHERE username = '"+name+"'";
    
     try{
            ps = conn.prepareStatement(query);
        
            rs = ps.executeQuery();
            DefaultTableModel dtm = (DefaultTableModel)scoreHistoryTable.getModel();
            dtm.setRowCount(0);
            while(rs.next()){
            Object obj[]={rs.getString("score")};
            dtm.addRow(obj);
            }
            
        } catch(SQLException sqle){
        
        }
    
 
    }
    
    
        public BeforeTest(String username, Locale l){
        initComponents();
        changeLang(l);
        scoreHistoryTable.setEnabled(false);
    welcomeLabel.setText(resBundle.getString("welcomeLabel"));
    nameLabel.setText(username);
    String name = nameLabel.getText();
      conn = DatabaseConnector.ConnectDatabase();
    String query = "SELECT * FROM roadtestscores WHERE username = '"+name+"'";
    
     try{
            ps = conn.prepareStatement(query);
        
            rs = ps.executeQuery();
            DefaultTableModel dtm = (DefaultTableModel)scoreHistoryTable.getModel();
            dtm.setRowCount(0);
            while(rs.next()){
            Object obj[]={rs.getString("score")};
            dtm.addRow(obj);
            }
            
        } catch(SQLException sqle){
        
        }
    
 
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        languageChoices = new javax.swing.ButtonGroup();
        beginButton = new javax.swing.JButton();
        chooseLangLabel = new javax.swing.JLabel();
        exitBtn = new javax.swing.JButton();
        rsaLabel = new javax.swing.JLabel();
        beforeTestLabel = new javax.swing.JLabel();
        welcomeLabel = new javax.swing.JLabel();
        dateLabel = new javax.swing.JLabel();
        nameLabel = new javax.swing.JLabel();
        scorePanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        scoreHistoryTable = new javax.swing.JTable();
        englishBtn = new javax.swing.JToggleButton();
        spanishBtn = new javax.swing.JToggleButton();
        japaneseBtn = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        beginButton.setText("Start Test");
        beginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beginButtonActionPerformed(evt);
            }
        });

        chooseLangLabel.setText("Please Choose Your Language:");

        exitBtn.setText("Exit");
        exitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitBtnActionPerformed(evt);
            }
        });

        rsaLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RoadSignsQuiz/RSALogo.jpg"))); // NOI18N

        beforeTestLabel.setText("There are 40 questions in this test. All questions carry equal points. You must score 35 or greater to pass");

        scorePanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        scoreHistoryTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "Your Previous Scores"
            }
        ));
        jScrollPane1.setViewportView(scoreHistoryTable);

        javax.swing.GroupLayout scorePanelLayout = new javax.swing.GroupLayout(scorePanel);
        scorePanel.setLayout(scorePanelLayout);
        scorePanelLayout.setHorizontalGroup(
            scorePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, scorePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );
        scorePanelLayout.setVerticalGroup(
            scorePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, scorePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                .addContainerGap())
        );

        languageChoices.add(englishBtn);
        englishBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RoadSignsQuiz/english.png"))); // NOI18N
        englishBtn.setText("English");
        englishBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                englishBtnActionPerformed(evt);
            }
        });

        languageChoices.add(spanishBtn);
        spanishBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RoadSignsQuiz/spanish.png"))); // NOI18N
        spanishBtn.setText("Spanish");
        spanishBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                spanishBtnActionPerformed(evt);
            }
        });

        languageChoices.add(japaneseBtn);
        japaneseBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RoadSignsQuiz/japanese.jpg"))); // NOI18N
        japaneseBtn.setText("Japanese");
        japaneseBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                japaneseBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(247, 247, 247)
                        .addComponent(beginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(exitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(beforeTestLabel))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(304, 304, 304)
                        .addComponent(chooseLangLabel))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 359, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(163, 163, 163)
                                .addComponent(englishBtn)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(spanishBtn)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(japaneseBtn))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(rsaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(70, 70, 70)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(welcomeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(nameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 102, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(scorePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(dateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(welcomeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addComponent(chooseLangLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scorePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(englishBtn)
                            .addComponent(spanishBtn)
                            .addComponent(japaneseBtn))
                        .addGap(17, 17, 17)
                        .addComponent(rsaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(beforeTestLabel)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(beginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(exitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void beginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beginButtonActionPerformed
       String candidateName = nameLabel.getText();
       if(englishBtn.isSelected()){
       new QuizTest(loc[0], candidateName).setVisible(true);
       this.setVisible(false);
       }
       
       else if(spanishBtn.isSelected()){
       new QuizTest(loc[1], candidateName).setVisible(true);
       this.setVisible(false);
       }
       
         else if(japaneseBtn.isSelected()){
       new QuizTest(loc[2], candidateName).setVisible(true);
       this.setVisible(false);
       }
    }//GEN-LAST:event_beginButtonActionPerformed

    private void exitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitBtnActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitBtnActionPerformed

    private void japaneseBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_japaneseBtnActionPerformed
        changeLang(loc[2]);

        String name = nameLabel.getText();
        conn = DatabaseConnector.ConnectDatabase();
        String query = "SELECT * FROM roadtestscores WHERE username = '"+name+"'";

        try{
            ps = conn.prepareStatement(query);

            rs = ps.executeQuery();
            DefaultTableModel dtm = (DefaultTableModel)scoreHistoryTable.getModel();
            dtm.setRowCount(0);
            while(rs.next()){
                Object obj[]={rs.getString("score")};
                dtm.addRow(obj);
            }

        } catch(SQLException sqle){

        }
    }//GEN-LAST:event_japaneseBtnActionPerformed

    private void englishBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_englishBtnActionPerformed
       changeLang(loc[0]);

  

        String name = nameLabel.getText();
        conn = DatabaseConnector.ConnectDatabase();
        String query = "SELECT * FROM roadtestscores WHERE username = '"+name+"'";

        try{
            ps = conn.prepareStatement(query);

            rs = ps.executeQuery();
            DefaultTableModel dtm = (DefaultTableModel)scoreHistoryTable.getModel();
            dtm.setRowCount(0);
            while(rs.next()){
                Object obj[]={rs.getString("score")};
                dtm.addRow(obj);
            }

        } catch(SQLException sqle){

        }
    }//GEN-LAST:event_englishBtnActionPerformed

    private void spanishBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_spanishBtnActionPerformed
       
changeLang(loc[1]);

  

        String name = nameLabel.getText();
        conn = DatabaseConnector.ConnectDatabase();
        String query = "SELECT * FROM roadtestscores WHERE username = '"+name+"'";

        try{
            ps = conn.prepareStatement(query);

            rs = ps.executeQuery();
            DefaultTableModel dtm = (DefaultTableModel)scoreHistoryTable.getModel();
            dtm.setRowCount(0);
            while(rs.next()){
                Object obj[]={rs.getString("score")};
                dtm.addRow(obj);
            }

        } catch(SQLException sqle){

        }
    }//GEN-LAST:event_spanishBtnActionPerformed

     public Connection getConnection(){
        Connection conn;
        
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost/roadsigntest", "root", "");
            return conn;
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
    }
        
        
        
        public void executeSQLQuery(String query, String notice)
    {
         try {
             Connection conn = getConnection();
             Statement st;
             st = conn.createStatement();
             try {
                 if((st.executeUpdate(query)) == 1)
                 {
                     JOptionPane.showMessageDialog(null, " Data " + notice + " successfully ");
                 }
                 
                 else{
                     JOptionPane.showMessageDialog(null, " Query Failed ");
                 }    } catch (SQLException ex) {
                     Logger.getLogger(BeforeTest.class.getName()).log(Level.SEVERE, null, ex);
                 }
             
         } catch (SQLException ex) {
             Logger.getLogger(BeforeTest.class.getName()).log(Level.SEVERE, null, ex);
         }

}
       
private void changeLang(Locale loc){
resBundle = ResourceBundle.getBundle("rbundles/ResourceBundle", loc);
beforeTestLabel.setText(resBundle.getString("beforeTestLabel"));
beginButton.setText(resBundle.getString("startTestBtn"));
chooseLangLabel.setText(resBundle.getString("chooseLangLabel"));
englishBtn.setText(resBundle.getString("englishBtn"));
spanishBtn.setText(resBundle.getString("spanishBtn"));
japaneseBtn.setText(resBundle.getString("japaneseBtn"));
exitBtn.setText(resBundle.getString("exitBtn"));
welcomeLabel.setText(resBundle.getString("welcomeLabel"));

 scoreHistoryTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                resBundle.getString("prevScore")
            }
        ));

 GregorianCalendar cal = new GregorianCalendar();
        DateFormat formatter = DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.FULL, loc);
        String date = formatter.format(cal.getTime());
        dateLabel.setText(date);
}
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BeforeTest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BeforeTest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BeforeTest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BeforeTest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BeforeTest().setVisible(false);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel beforeTestLabel;
    private javax.swing.JButton beginButton;
    private javax.swing.JLabel chooseLangLabel;
    private javax.swing.JLabel dateLabel;
    private javax.swing.JToggleButton englishBtn;
    private javax.swing.JButton exitBtn;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JToggleButton japaneseBtn;
    private javax.swing.ButtonGroup languageChoices;
    private javax.swing.JLabel nameLabel;
    private javax.swing.JLabel rsaLabel;
    private javax.swing.JTable scoreHistoryTable;
    private javax.swing.JPanel scorePanel;
    private javax.swing.JToggleButton spanishBtn;
    private javax.swing.JLabel welcomeLabel;
    // End of variables declaration//GEN-END:variables
}
