package RoadSignsQuiz;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class QuizTest extends javax.swing.JFrame {

    static ResourceBundle rBundle = ResourceBundle.getBundle("rbundles/ResourceBundle");//Fetches the resource bundles for the languages
    ArrayList<Integer> asked = new ArrayList<>();//This ArrayList is used to index the questions that are already asked
    Locale[] loc = {new Locale("en", "GB"), new Locale("es", "ES"), new Locale("ja", "JP")};//Locales for the relevant languages
    int score = 0;//This variable is used to keep track of the score
    int incorrectAnswers = 0;//Counts all the answers that were wrongly answered
    int x;
    int noOfQuestionsAsked = 1;//This variable is used to keep track of the number of questions asked
    
    Feedback feedback = new Feedback();//Creates an object of the feedback JFrame
    
    String imageNames[] = {"Advance information sign for low clearance.gif", "Airport.gif", "Alternative route for high vehicles.gif", "Cul-de-sac.gif", "Destination distance.gif", "Disabled persons parking bay.gif", "Ferry.gif", "Hospital sign.gif", "Motorway.gif", "National Road.gif", "Regional road direction.gif", "Regional road.gif", "SOS lay-by.gif", "Town or village.gif", "Traffic calming.gif", "100m to next exit.gif", "200m to next exit.gif", "300m to next exit.gif", "Advance direction sign for destination.gif", "Advance direction sign.gif", "Entry to motorway.gif", "Motorway ahead.gif", "Motorway ends 1km ahead.gif", "Motorway ends 500m ahead.gif", "Route Confirmatory sign for M7.gif", "Bus lane on left.gif", "Bus only street.gif", "Clearway.gif", "Disk Parking.gif", "Electronic periodic speed limit sign.gif", "Electronic variable speed limit sign (tunnel only).gif", "End of cycle track.gif", "End of the restriction zone.gif", "Height Restriction.gif", "In a tunnel goods vehicles cannot use right-hand lane (by reference to number of axles).gif", "Max speed limit 120kph.gif", "Max speed limit 30kph.gif", "No Left Turn.gif", "No U Turn.gif", "No entry for pedestrians to tramway.gif", "No entry to goods vehicles (by reference to number of axles).gif", "No entry.gif", "No overtaking.gif", "No right turn.gif", "Parking permitted.gif", "Parking prohibited.gif", "Pedestrianised street.gif", "School wardens stop sign.gif", "Start of cycle track.gif", "Stop.gif", "Taxi Rank.gif", "Tram lane on right.gif", "Tram only street.gif", "Weight Restriction.gif", "Yield en.gif", "Zonal restriction - no parking of large vehicles.gif", "Advance direction to local services.gif", "Advance sign for lay-by with tourism information.gif", "Oige youth hostels.gif", "Pedestrian sign to a car park.gif", "Pedestrian sign to a tourist attraction.gif", "Sign to approved tourist information point.gif", "Tourist advanced direction sign.gif", "Tourist attraction direction sign.gif", "Accompanied horses and ponies.gif", "Cattle and farm animals.gif", "Crosswinds.gif", "Deer or wild animals.gif", "Drive on left.gif", "Level crossing ahead with lights and barriers.gif", "Low flying aircraft.gif", "Overhead electric cables.gif", "Pedestrian crossing ahead.gif", "Sharp dip ahead.gif", "Sharp rise ahead e.g. hump-back bridge.gif", "Slippery road ahead.gif", "Steep descent ahead.gif", "Traffic signals ahead.gif", "Tunnel ahead.gif", "Unprotected quay, canal or river ahead.gif", "Diverted traffic left.gif", "Flagman ahead.gif", "Loose chippings.gif", "Queues likely.gif", "Roadworks ahead.gif", "Site access on left.gif", "Uneven surface.gif", "Dangerous bend ahead.gif", "Dangerous corner ahead.gif", "Merging traffic.gif", "Mini-Roundabout ahead.gif", "Restricted headroom.gif", "Roundabout ahead.gif", "Series of dangerous bends ahead.gif", "Series of dangerous corners ahead.gif", "Two-way traffic.gif"};
   
    ImageIcon images[] = new ImageIcon[96];
    
    

    public QuizTest() {
        initComponents();
        changeLang(loc[0]);
        handleRandomGenerator();
    }
    
    public QuizTest(Locale l, String candidate){//This constructor is used to pass the name value of the logged in candidate and the selected locale 
        initComponents();
        changeLang(l);//sets it to the language of the user's choice
        handleRandomGenerator();//When the user begins the test, a random question is generated
        candidateNameLabel.setText(candidate);//Displays the name of the user
        

    
    }
    
    
    
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        answerButtons = new javax.swing.ButtonGroup();
        choice1 = new javax.swing.JRadioButton();
        nextQBtn = new javax.swing.JButton();
        choice3 = new javax.swing.JRadioButton();
        choice4 = new javax.swing.JRadioButton();
        questionLabel = new javax.swing.JLabel();
        choice2 = new javax.swing.JRadioButton();
        imgLabel = new javax.swing.JLabel();
        chooseLangLabel = new javax.swing.JLabel();
        englishBtn = new javax.swing.JButton();
        spanishBtn = new javax.swing.JButton();
        japaneseBtn = new javax.swing.JButton();
        dateLabel = new javax.swing.JLabel();
        scoreLabel = new javax.swing.JLabel();
        exitBtn = new javax.swing.JButton();
        candidateNameLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        answerButtons.add(choice1);

        nextQBtn.setText("Next");
        nextQBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextQBtnActionPerformed(evt);
            }
        });

        answerButtons.add(choice3);

        answerButtons.add(choice4);

        answerButtons.add(choice2);

        chooseLangLabel.setText("Please Choose Your Language:");

        englishBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RoadSignsQuiz/english.png"))); // NOI18N
        englishBtn.setText("English");
        englishBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                englishBtnActionPerformed(evt);
            }
        });

        spanishBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RoadSignsQuiz/spanish.png"))); // NOI18N
        spanishBtn.setText("Spanish");
        spanishBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                spanishBtnActionPerformed(evt);
            }
        });

        japaneseBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/RoadSignsQuiz/japanese.jpg"))); // NOI18N
        japaneseBtn.setText("Japanese");
        japaneseBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                japaneseBtnActionPerformed(evt);
            }
        });

        scoreLabel.setText("Score: ");

        exitBtn.setText("Exit");
        exitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 344, Short.MAX_VALUE)
                        .addComponent(nextQBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(exitBtn)
                        .addGap(540, 540, 540))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(choice3, javax.swing.GroupLayout.DEFAULT_SIZE, 309, Short.MAX_VALUE)
                                    .addComponent(choice1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(choice2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(choice4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(210, 210, 210)
                                .addComponent(imgLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(dateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(136, 136, 136)
                                        .addComponent(englishBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(spanishBtn)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(japaneseBtn)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(scoreLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(candidateNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap())))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(244, 244, 244)
                        .addComponent(chooseLangLabel))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(175, 175, 175)
                        .addComponent(questionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(candidateNameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(dateLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(chooseLangLabel)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(englishBtn)
                            .addComponent(spanishBtn)
                            .addComponent(japaneseBtn)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(scoreLabel)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addComponent(questionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(imgLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(choice2, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(choice1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(choice3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(choice4, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(exitBtn)
                    .addComponent(nextQBtn)))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void englishBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_englishBtnActionPerformed
        changeLang(loc[0]);//Sets it to English
        iniScore(score);//Updates the score

        if (noOfQuestionsAsked == 40) {
            nextQBtn.setText(rBundle.getString("finishBtn"));//Finish button appears when the number of questions reaches 40

        }
    }//GEN-LAST:event_englishBtnActionPerformed

    private void spanishBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_spanishBtnActionPerformed
        changeLang(loc[1]);//Sets it to Spanish
        iniScore(score);//Updates the score
        
        if (noOfQuestionsAsked == 40) {
            nextQBtn.setText(rBundle.getString("finishBtn"));//Finish button appears when the number of questions reaches 40

        }
    }//GEN-LAST:event_spanishBtnActionPerformed

    private void japaneseBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_japaneseBtnActionPerformed
        changeLang(loc[2]);//Sets it to Japanese
        iniScore(score);//Updates the score

        if (noOfQuestionsAsked == 40) {
            nextQBtn.setText(rBundle.getString("finishBtn"));//Finish button appears when the number of questions reaches 40

        }
    }//GEN-LAST:event_japaneseBtnActionPerformed

    private void nextQBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextQBtnActionPerformed
   String correctAnswers[] = {rBundle.getString("infoSignQ1choice4"), rBundle.getString("infoSignQ2choice2"), rBundle.getString("infoSignQ3choice3"), rBundle.getString("infoSignQ4choice1"), rBundle.getString("infoSignQ5choice4"), rBundle.getString("infoSignQ6choice2"), rBundle.getString("infoSignQ7choice3"), rBundle.getString("infoSignQ8choice3"), rBundle.getString("infoSignQ9choice2"), rBundle.getString("infoSignQ10choice1"), rBundle.getString("infoSignQ11choice2"), rBundle.getString("infoSignQ12choice1"), rBundle.getString("infoSignQ13choice4"), rBundle.getString("infoSignQ14choice3"), rBundle.getString("infoSignQ15choice3"), rBundle.getString("motorwaySignQ1choice1"), rBundle.getString("motorwaySignQ2choice1"), rBundle.getString("motorwaySignQ3choice1"),rBundle.getString("motorwaySignQ4choice4"),rBundle.getString("motorwaySignQ5choice3"),rBundle.getString("motorwaySignQ6choice2"),rBundle.getString("motorwaySignQ7choice4"),rBundle.getString("motorwaySignQ8choice3"),rBundle.getString("motorwaySignQ9choice3"),rBundle.getString("motorwaySignQ10choice1"),rBundle.getString("regulatoryTrafficSignQ1choice2"),rBundle.getString("regulatoryTrafficSignQ2choice3"),rBundle.getString("regulatoryTrafficSignQ3choice4"),rBundle.getString("regulatoryTrafficSignQ4choice2"),rBundle.getString("regulatoryTrafficSignQ5choice3"),rBundle.getString("regulatoryTrafficSignQ6choice3"),rBundle.getString("regulatoryTrafficSignQ7choice1"),rBundle.getString("regulatoryTrafficSignQ8choice2"),rBundle.getString("regulatoryTrafficSignQ9choice3"),rBundle.getString("regulatoryTrafficSignQ10choice3"),rBundle.getString("regulatoryTrafficSignQ11choice2"),rBundle.getString("regulatoryTrafficSignQ12choice2"),rBundle.getString("regulatoryTrafficSignQ13choice4"),rBundle.getString("regulatoryTrafficSignQ14choice3"),rBundle.getString("regulatoryTrafficSignQ15choice3"),rBundle.getString("regulatoryTrafficSignQ16choice3"),rBundle.getString("regulatoryTrafficSignQ17choice1"),rBundle.getString("regulatoryTrafficSignQ18choice2"),rBundle.getString("regulatoryTrafficSignQ19choice4"),rBundle.getString("regulatoryTrafficSignQ20choice4"),rBundle.getString("regulatoryTrafficSignQ21choice4"),rBundle.getString("regulatoryTrafficSignQ22choice2"),rBundle.getString("regulatoryTrafficSignQ23choice1"),rBundle.getString("regulatoryTrafficSignQ24choice2"),rBundle.getString("regulatoryTrafficSignQ25choice3"),rBundle.getString("regulatoryTrafficSignQ26choice1"),rBundle.getString("regulatoryTrafficSignQ27choice1"),rBundle.getString("regulatoryTrafficSignQ28choice2"),rBundle.getString("regulatoryTrafficSignQ29choice4"),rBundle.getString("regulatoryTrafficSignQ30choice1"),rBundle.getString("regulatoryTrafficSignQ31choice3"), rBundle.getString("touristSignQ1choice2"), rBundle.getString("touristSignQ2choice3"), rBundle.getString("touristSignQ3choice1"), rBundle.getString("touristSignQ4choice3"), rBundle.getString("touristSignQ5choice4"), rBundle.getString("touristSignQ6choice1"), rBundle.getString("touristSignQ7choice2"), rBundle.getString("touristSignQ8choice3"),rBundle.getString("warningSignQ1choice3"),rBundle.getString("warningSignQ2choice2"),rBundle.getString("warningSignQ3choice2"),rBundle.getString("warningSignQ4choice4"),rBundle.getString("warningSignQ5choice3"),rBundle.getString("warningSignQ6choice3"),rBundle.getString("warningSignQ7choice3"),rBundle.getString("warningSignQ8choice3"),rBundle.getString("warningSignQ9choice4"),rBundle.getString("warningSignQ10choice2"),rBundle.getString("warningSignQ11choice3"),rBundle.getString("warningSignQ12choice1"),rBundle.getString("warningSignQ13choice4"),rBundle.getString("warningSignQ14choice1"),rBundle.getString("warningSignQ15choice4"),rBundle.getString("warningSignQ16choice3"),rBundle.getString("warningSignQ17choice2"),rBundle.getString("warningSignQ18choice1"),rBundle.getString("warningSignQ19choice3"),rBundle.getString("warningSignQ20choice4"),rBundle.getString("warningSignQ21choice1"),rBundle.getString("warningSignQ22choice2"),rBundle.getString("warningSignQ23choice3"),rBundle.getString("warningSignQ24choice2"),rBundle.getString("warningSignQ25choice3"),rBundle.getString("warningSignQ26choice1"),rBundle.getString("warningSignQ27choice4"),rBundle.getString("warningSignQ28choice1"),rBundle.getString("warningSignQ29choice3"),rBundle.getString("warningSignQ30choice2"),rBundle.getString("warningSignQ31choice3"),rBundle.getString("warningSignQ32choice1")};
   //This 1D array stores all the correct answers for every single question
        try{
        getSelectedButtonText(answerButtons);//Loops through the 4 radio buttons to check if the user selected a correct or incorrect answer

        if (correctAnswers[x].equals(getSelectedButtonText(answerButtons))){//if the user selects the correct answer of a question
            
            JOptionPane.showMessageDialog(null, rBundle.getString("correctAns"), rBundle.getString("right"), JOptionPane.INFORMATION_MESSAGE);
            score = score + 1;//Adds one point if the user selects correct answer
            noOfQuestionsAsked = noOfQuestionsAsked + 1;//Keeps track of the number of questions asked
            setTitle(rBundle.getString("examTitle") + " " + noOfQuestionsAsked);//Displays the question number on the title
            scoreLabel.setText(rBundle.getString("scoreLabel") + " " + score);
            
        } else {//else if the user selects a wrong answer
            noOfQuestionsAsked = noOfQuestionsAsked + 1;
            incorrectAnswers = incorrectAnswers + 1;//Keeps track of the number of wrong answers
            setTitle(rBundle.getString("examTitle") + " " + noOfQuestionsAsked);
            JOptionPane.showMessageDialog(null, rBundle.getString("incorrectAns"), rBundle.getString("wrong"), JOptionPane.WARNING_MESSAGE);
        }
        
        handleRandomGenerator();//When the next button is clicked, it generates a different random question from the array
   }catch(NullPointerException | ArrayIndexOutOfBoundsException e){//Catches all possible exceptions
   
   }
    }//GEN-LAST:event_nextQBtnActionPerformed

    private void exitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitBtnActionPerformed
        System.exit(0);//Exits the test
    }//GEN-LAST:event_exitBtnActionPerformed

     public Connection getConnection(){
        Connection conn;
        
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost/roadsigntest", "root", "");
            return conn;
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
    }
          
          
          
                 public void executeSQLQuery(String query, String notice)
    {
         try {
             Connection conn = getConnection();
             Statement st;
             st = conn.createStatement();
             try {
                 if((st.executeUpdate(query)) == 1)
                 {
                     //JOptionPane.showMessageDialog(null,  notice, rBundle.getString("successT"), JOptionPane.PLAIN_MESSAGE );
                 }
                 
                 else{
                     JOptionPane.showMessageDialog(null, " Query Failed ");
                 }    } catch (SQLException ex) {
                     Logger.getLogger(QuizTest.class.getName()).log(Level.SEVERE, null, ex);
                 }
             
         } catch (SQLException ex) {
             Logger.getLogger(QuizTest.class.getName()).log(Level.SEVERE, null, ex);
         }
  
    }
    
    private void changeLang(Locale loc) {//This method changes the language depending on the user's selection
        rBundle = ResourceBundle.getBundle("rbundles/ResourceBundle", loc);
        chooseLangLabel.setText(rBundle.getString("chooseLangLabel"));
        englishBtn.setText(rBundle.getString("englishBtn"));
        spanishBtn.setText(rBundle.getString("spanishBtn"));
        japaneseBtn.setText(rBundle.getString("japaneseBtn"));
        questionLabel.setText(rBundle.getString("questionLabelSign"));
        
        String answers[][] = {//2D array created to store and correspond the answers to their relevant questions
        {rBundle.getString("infoSignQ1choice1"), rBundle.getString("infoSignQ1choice2"), rBundle.getString("infoSignQ1choice3"), rBundle.getString("infoSignQ1choice4")},
        {rBundle.getString("infoSignQ2choice1"), rBundle.getString("infoSignQ2choice2"), rBundle.getString("infoSignQ2choice3"), rBundle.getString("infoSignQ2choice4")},
        {rBundle.getString("infoSignQ3choice1"), rBundle.getString("infoSignQ3choice2"), rBundle.getString("infoSignQ3choice3"), rBundle.getString("infoSignQ3choice4")},
        {rBundle.getString("infoSignQ4choice1"), rBundle.getString("infoSignQ4choice2"), rBundle.getString("infoSignQ4choice3"), rBundle.getString("infoSignQ4choice4")},
        {rBundle.getString("infoSignQ5choice1"), rBundle.getString("infoSignQ5choice2"), rBundle.getString("infoSignQ5choice3"), rBundle.getString("infoSignQ5choice4")},
        {rBundle.getString("infoSignQ6choice1"), rBundle.getString("infoSignQ6choice2"), rBundle.getString("infoSignQ6choice3"), rBundle.getString("infoSignQ6choice4")},
        {rBundle.getString("infoSignQ7choice1"), rBundle.getString("infoSignQ7choice2"), rBundle.getString("infoSignQ7choice3"), rBundle.getString("infoSignQ7choice4")},
        {rBundle.getString("infoSignQ8choice1"), rBundle.getString("infoSignQ8choice2"), rBundle.getString("infoSignQ8choice3"), rBundle.getString("infoSignQ8choice4")},
        {rBundle.getString("infoSignQ9choice1"), rBundle.getString("infoSignQ9choice2"), rBundle.getString("infoSignQ9choice3"), rBundle.getString("infoSignQ9choice4")},
        {rBundle.getString("infoSignQ10choice1"), rBundle.getString("infoSignQ10choice2"), rBundle.getString("infoSignQ10choice3"), rBundle.getString("infoSignQ10choice4")},
        {rBundle.getString("infoSignQ11choice1"), rBundle.getString("infoSignQ11choice2"), rBundle.getString("infoSignQ11choice3"), rBundle.getString("infoSignQ11choice4")},
        {rBundle.getString("infoSignQ12choice1"), rBundle.getString("infoSignQ12choice2"), rBundle.getString("infoSignQ12choice3"), rBundle.getString("infoSignQ12choice4")},
        {rBundle.getString("infoSignQ13choice1"), rBundle.getString("infoSignQ13choice2"), rBundle.getString("infoSignQ13choice3"), rBundle.getString("infoSignQ13choice4")},
        {rBundle.getString("infoSignQ14choice1"), rBundle.getString("infoSignQ14choice2"), rBundle.getString("infoSignQ14choice3"), rBundle.getString("infoSignQ14choice4")},
        {rBundle.getString("infoSignQ15choice1"), rBundle.getString("infoSignQ15choice2"), rBundle.getString("infoSignQ15choice3"), rBundle.getString("infoSignQ15choice4")},
        {rBundle.getString("motorwaySignQ1choice1"), rBundle.getString("motorwaySignQ1choice2"), rBundle.getString("motorwaySignQ1choice3"), rBundle.getString("motorwaySignQ1choice4")},
        {rBundle.getString("motorwaySignQ2choice1"), rBundle.getString("motorwaySignQ2choice2"), rBundle.getString("motorwaySignQ2choice3"), rBundle.getString("motorwaySignQ2choice4")},
        {rBundle.getString("motorwaySignQ3choice1"), rBundle.getString("motorwaySignQ3choice2"), rBundle.getString("motorwaySignQ3choice3"), rBundle.getString("motorwaySignQ3choice4")},
        {rBundle.getString("motorwaySignQ4choice1"), rBundle.getString("motorwaySignQ4choice2"), rBundle.getString("motorwaySignQ4choice3"), rBundle.getString("motorwaySignQ4choice4")},
        {rBundle.getString("motorwaySignQ5choice1"), rBundle.getString("motorwaySignQ5choice2"), rBundle.getString("motorwaySignQ5choice3"), rBundle.getString("motorwaySignQ5choice4")},
        {rBundle.getString("motorwaySignQ6choice1"), rBundle.getString("motorwaySignQ6choice2"), rBundle.getString("motorwaySignQ6choice3"), rBundle.getString("motorwaySignQ6choice4")},
        {rBundle.getString("motorwaySignQ7choice1"), rBundle.getString("motorwaySignQ7choice2"), rBundle.getString("motorwaySignQ7choice3"), rBundle.getString("motorwaySignQ7choice4")},
        {rBundle.getString("motorwaySignQ8choice1"), rBundle.getString("motorwaySignQ8choice2"), rBundle.getString("motorwaySignQ8choice3"), rBundle.getString("motorwaySignQ8choice4")},
        {rBundle.getString("motorwaySignQ9choice1"), rBundle.getString("motorwaySignQ9choice2"), rBundle.getString("motorwaySignQ9choice3"), rBundle.getString("motorwaySignQ9choice4")},
        {rBundle.getString("motorwaySignQ10choice1"), rBundle.getString("motorwaySignQ10choice2"), rBundle.getString("motorwaySignQ10choice3"), rBundle.getString("motorwaySignQ10choice4")},
        {rBundle.getString("regulatoryTrafficSignQ1choice1"), rBundle.getString("regulatoryTrafficSignQ1choice2"), rBundle.getString("regulatoryTrafficSignQ1choice3"), rBundle.getString("regulatoryTrafficSignQ1choice4")},
        {rBundle.getString("regulatoryTrafficSignQ2choice1"), rBundle.getString("regulatoryTrafficSignQ2choice2"), rBundle.getString("regulatoryTrafficSignQ2choice3"), rBundle.getString("regulatoryTrafficSignQ2choice4")},
        {rBundle.getString("regulatoryTrafficSignQ3choice1"), rBundle.getString("regulatoryTrafficSignQ3choice2"), rBundle.getString("regulatoryTrafficSignQ3choice3"), rBundle.getString("regulatoryTrafficSignQ3choice4")},
        {rBundle.getString("regulatoryTrafficSignQ4choice1"), rBundle.getString("regulatoryTrafficSignQ4choice2"), rBundle.getString("regulatoryTrafficSignQ4choice3"), rBundle.getString("regulatoryTrafficSignQ4choice4")},
        {rBundle.getString("regulatoryTrafficSignQ5choice1"), rBundle.getString("regulatoryTrafficSignQ5choice2"), rBundle.getString("regulatoryTrafficSignQ5choice3"), rBundle.getString("regulatoryTrafficSignQ5choice4")},
        {rBundle.getString("regulatoryTrafficSignQ6choice1"), rBundle.getString("regulatoryTrafficSignQ6choice2"), rBundle.getString("regulatoryTrafficSignQ6choice3"), rBundle.getString("regulatoryTrafficSignQ6choice4")},
        {rBundle.getString("regulatoryTrafficSignQ7choice1"), rBundle.getString("regulatoryTrafficSignQ7choice2"), rBundle.getString("regulatoryTrafficSignQ7choice3"), rBundle.getString("regulatoryTrafficSignQ7choice4")},
        {rBundle.getString("regulatoryTrafficSignQ8choice1"), rBundle.getString("regulatoryTrafficSignQ8choice2"), rBundle.getString("regulatoryTrafficSignQ8choice3"), rBundle.getString("regulatoryTrafficSignQ8choice4")},
        {rBundle.getString("regulatoryTrafficSignQ9choice1"), rBundle.getString("regulatoryTrafficSignQ9choice2"), rBundle.getString("regulatoryTrafficSignQ9choice3"), rBundle.getString("regulatoryTrafficSignQ9choice4")},
        {rBundle.getString("regulatoryTrafficSignQ10choice1"), rBundle.getString("regulatoryTrafficSignQ10choice2"), rBundle.getString("regulatoryTrafficSignQ10choice3"), rBundle.getString("regulatoryTrafficSignQ10choice4")},
        {rBundle.getString("regulatoryTrafficSignQ11choice1"), rBundle.getString("regulatoryTrafficSignQ11choice2"), rBundle.getString("regulatoryTrafficSignQ11choice3"), rBundle.getString("regulatoryTrafficSignQ11choice4")},
        {rBundle.getString("regulatoryTrafficSignQ12choice1"), rBundle.getString("regulatoryTrafficSignQ12choice2"), rBundle.getString("regulatoryTrafficSignQ12choice3"), rBundle.getString("regulatoryTrafficSignQ12choice4")},
        {rBundle.getString("regulatoryTrafficSignQ13choice1"), rBundle.getString("regulatoryTrafficSignQ13choice2"), rBundle.getString("regulatoryTrafficSignQ13choice3"), rBundle.getString("regulatoryTrafficSignQ13choice4")},
        {rBundle.getString("regulatoryTrafficSignQ14choice1"), rBundle.getString("regulatoryTrafficSignQ14choice2"), rBundle.getString("regulatoryTrafficSignQ14choice3"), rBundle.getString("regulatoryTrafficSignQ14choice4")},
        {rBundle.getString("regulatoryTrafficSignQ15choice1"), rBundle.getString("regulatoryTrafficSignQ15choice2"), rBundle.getString("regulatoryTrafficSignQ15choice3"), rBundle.getString("regulatoryTrafficSignQ15choice4")},
        {rBundle.getString("regulatoryTrafficSignQ16choice1"), rBundle.getString("regulatoryTrafficSignQ16choice2"), rBundle.getString("regulatoryTrafficSignQ16choice3"), rBundle.getString("regulatoryTrafficSignQ16choice4")},
        {rBundle.getString("regulatoryTrafficSignQ17choice1"), rBundle.getString("regulatoryTrafficSignQ17choice2"), rBundle.getString("regulatoryTrafficSignQ17choice3"), rBundle.getString("regulatoryTrafficSignQ17choice4")},
        {rBundle.getString("regulatoryTrafficSignQ18choice1"), rBundle.getString("regulatoryTrafficSignQ18choice2"), rBundle.getString("regulatoryTrafficSignQ18choice3"), rBundle.getString("regulatoryTrafficSignQ18choice4")},
        {rBundle.getString("regulatoryTrafficSignQ19choice1"), rBundle.getString("regulatoryTrafficSignQ19choice2"), rBundle.getString("regulatoryTrafficSignQ19choice3"), rBundle.getString("regulatoryTrafficSignQ19choice4")},
        {rBundle.getString("regulatoryTrafficSignQ20choice1"), rBundle.getString("regulatoryTrafficSignQ20choice2"), rBundle.getString("regulatoryTrafficSignQ20choice3"), rBundle.getString("regulatoryTrafficSignQ20choice4")},
        {rBundle.getString("regulatoryTrafficSignQ21choice1"), rBundle.getString("regulatoryTrafficSignQ21choice2"), rBundle.getString("regulatoryTrafficSignQ21choice3"), rBundle.getString("regulatoryTrafficSignQ21choice4")},
        {rBundle.getString("regulatoryTrafficSignQ22choice1"), rBundle.getString("regulatoryTrafficSignQ22choice2"), rBundle.getString("regulatoryTrafficSignQ22choice3"), rBundle.getString("regulatoryTrafficSignQ22choice4")},
        {rBundle.getString("regulatoryTrafficSignQ23choice1"), rBundle.getString("regulatoryTrafficSignQ23choice2"), rBundle.getString("regulatoryTrafficSignQ23choice3"), rBundle.getString("regulatoryTrafficSignQ23choice4")},
        {rBundle.getString("regulatoryTrafficSignQ24choice1"), rBundle.getString("regulatoryTrafficSignQ24choice2"), rBundle.getString("regulatoryTrafficSignQ24choice3"), rBundle.getString("regulatoryTrafficSignQ24choice4")},
        {rBundle.getString("regulatoryTrafficSignQ25choice1"), rBundle.getString("regulatoryTrafficSignQ25choice2"), rBundle.getString("regulatoryTrafficSignQ25choice3"), rBundle.getString("regulatoryTrafficSignQ25choice4")},
        {rBundle.getString("regulatoryTrafficSignQ26choice1"), rBundle.getString("regulatoryTrafficSignQ26choice2"), rBundle.getString("regulatoryTrafficSignQ26choice3"), rBundle.getString("regulatoryTrafficSignQ26choice4")},
        {rBundle.getString("regulatoryTrafficSignQ27choice1"), rBundle.getString("regulatoryTrafficSignQ27choice2"), rBundle.getString("regulatoryTrafficSignQ27choice3"), rBundle.getString("regulatoryTrafficSignQ27choice4")},
        {rBundle.getString("regulatoryTrafficSignQ28choice1"), rBundle.getString("regulatoryTrafficSignQ28choice2"), rBundle.getString("regulatoryTrafficSignQ28choice3"), rBundle.getString("regulatoryTrafficSignQ28choice4")},
        {rBundle.getString("regulatoryTrafficSignQ29choice1"), rBundle.getString("regulatoryTrafficSignQ29choice2"), rBundle.getString("regulatoryTrafficSignQ29choice3"), rBundle.getString("regulatoryTrafficSignQ29choice4")},
        {rBundle.getString("regulatoryTrafficSignQ30choice1"), rBundle.getString("regulatoryTrafficSignQ30choice2"), rBundle.getString("regulatoryTrafficSignQ30choice3"), rBundle.getString("regulatoryTrafficSignQ30choice4")},
        {rBundle.getString("regulatoryTrafficSignQ31choice1"), rBundle.getString("regulatoryTrafficSignQ31choice2"), rBundle.getString("regulatoryTrafficSignQ31choice3"), rBundle.getString("regulatoryTrafficSignQ31choice4")},
        {rBundle.getString("touristSignQ1choice1"),rBundle.getString("touristSignQ1choice2"),rBundle.getString("touristSignQ1choice3"),rBundle.getString("touristSignQ1choice4")},
        {rBundle.getString("touristSignQ2choice1"),rBundle.getString("touristSignQ2choice2"),rBundle.getString("touristSignQ2choice3"),rBundle.getString("touristSignQ2choice4")},
        {rBundle.getString("touristSignQ3choice1"),rBundle.getString("touristSignQ3choice2"),rBundle.getString("touristSignQ3choice3"),rBundle.getString("touristSignQ3choice4")},
        {rBundle.getString("touristSignQ4choice1"),rBundle.getString("touristSignQ4choice2"),rBundle.getString("touristSignQ4choice3"),rBundle.getString("touristSignQ4choice4")},
        {rBundle.getString("touristSignQ5choice1"),rBundle.getString("touristSignQ5choice2"),rBundle.getString("touristSignQ5choice3"),rBundle.getString("touristSignQ5choice4")},
        {rBundle.getString("touristSignQ6choice1"),rBundle.getString("touristSignQ6choice2"),rBundle.getString("touristSignQ6choice3"),rBundle.getString("touristSignQ6choice4")},
        {rBundle.getString("touristSignQ7choice1"),rBundle.getString("touristSignQ7choice2"),rBundle.getString("touristSignQ7choice3"),rBundle.getString("touristSignQ7choice4")},
        {rBundle.getString("touristSignQ8choice1"),rBundle.getString("touristSignQ8choice2"),rBundle.getString("touristSignQ8choice3"),rBundle.getString("touristSignQ8choice4")},
        {rBundle.getString("warningSignQ1choice1"),rBundle.getString("warningSignQ1choice2"),rBundle.getString("warningSignQ1choice3"),rBundle.getString("warningSignQ1choice4")},
        {rBundle.getString("warningSignQ2choice1"),rBundle.getString("warningSignQ2choice2"),rBundle.getString("warningSignQ2choice3"),rBundle.getString("warningSignQ2choice4")},
        {rBundle.getString("warningSignQ3choice1"),rBundle.getString("warningSignQ3choice2"),rBundle.getString("warningSignQ3choice3"),rBundle.getString("warningSignQ3choice4")},
        {rBundle.getString("warningSignQ4choice1"),rBundle.getString("warningSignQ4choice2"),rBundle.getString("warningSignQ4choice3"),rBundle.getString("warningSignQ4choice4")},
        {rBundle.getString("warningSignQ5choice1"),rBundle.getString("warningSignQ5choice2"),rBundle.getString("warningSignQ5choice3"),rBundle.getString("warningSignQ5choice4")},
        {rBundle.getString("warningSignQ6choice1"),rBundle.getString("warningSignQ6choice2"),rBundle.getString("warningSignQ6choice3"),rBundle.getString("warningSignQ6choice4")},
        {rBundle.getString("warningSignQ7choice1"),rBundle.getString("warningSignQ7choice2"),rBundle.getString("warningSignQ7choice3"),rBundle.getString("warningSignQ7choice4")},
        {rBundle.getString("warningSignQ8choice1"),rBundle.getString("warningSignQ8choice2"),rBundle.getString("warningSignQ8choice3"),rBundle.getString("warningSignQ8choice4")},
        {rBundle.getString("warningSignQ9choice1"),rBundle.getString("warningSignQ9choice2"),rBundle.getString("warningSignQ9choice3"),rBundle.getString("warningSignQ9choice4")},
        {rBundle.getString("warningSignQ10choice1"),rBundle.getString("warningSignQ10choice2"),rBundle.getString("warningSignQ10choice3"),rBundle.getString("warningSignQ10choice4")},
        {rBundle.getString("warningSignQ11choice1"),rBundle.getString("warningSignQ11choice2"),rBundle.getString("warningSignQ11choice3"),rBundle.getString("warningSignQ11choice4")},
        {rBundle.getString("warningSignQ12choice1"),rBundle.getString("warningSignQ12choice2"),rBundle.getString("warningSignQ12choice3"),rBundle.getString("warningSignQ12choice4")},
        {rBundle.getString("warningSignQ13choice1"),rBundle.getString("warningSignQ13choice2"),rBundle.getString("warningSignQ13choice3"),rBundle.getString("warningSignQ13choice4")},
        {rBundle.getString("warningSignQ14choice1"),rBundle.getString("warningSignQ14choice2"),rBundle.getString("warningSignQ14choice3"),rBundle.getString("warningSignQ14choice4")},
        {rBundle.getString("warningSignQ15choice1"),rBundle.getString("warningSignQ15choice2"),rBundle.getString("warningSignQ15choice3"),rBundle.getString("warningSignQ15choice4")},
        {rBundle.getString("warningSignQ16choice1"),rBundle.getString("warningSignQ16choice2"),rBundle.getString("warningSignQ16choice3"),rBundle.getString("warningSignQ16choice4")},
        {rBundle.getString("warningSignQ17choice1"),rBundle.getString("warningSignQ17choice2"),rBundle.getString("warningSignQ17choice3"),rBundle.getString("warningSignQ17choice4")},
        {rBundle.getString("warningSignQ18choice1"),rBundle.getString("warningSignQ18choice2"),rBundle.getString("warningSignQ18choice3"),rBundle.getString("warningSignQ18choice4")},
        {rBundle.getString("warningSignQ19choice1"),rBundle.getString("warningSignQ19choice2"),rBundle.getString("warningSignQ19choice3"),rBundle.getString("warningSignQ19choice4")},
        {rBundle.getString("warningSignQ20choice1"),rBundle.getString("warningSignQ20choice2"),rBundle.getString("warningSignQ20choice3"),rBundle.getString("warningSignQ20choice4")},
        {rBundle.getString("warningSignQ21choice1"),rBundle.getString("warningSignQ21choice2"),rBundle.getString("warningSignQ21choice3"),rBundle.getString("warningSignQ21choice4")},
        {rBundle.getString("warningSignQ22choice1"),rBundle.getString("warningSignQ22choice2"),rBundle.getString("warningSignQ22choice3"),rBundle.getString("warningSignQ22choice4")},
        {rBundle.getString("warningSignQ23choice1"),rBundle.getString("warningSignQ23choice2"),rBundle.getString("warningSignQ23choice3"),rBundle.getString("warningSignQ23choice4")},
        {rBundle.getString("warningSignQ24choice1"),rBundle.getString("warningSignQ24choice2"),rBundle.getString("warningSignQ24choice3"),rBundle.getString("warningSignQ24choice4")},
        {rBundle.getString("warningSignQ25choice1"),rBundle.getString("warningSignQ25choice2"),rBundle.getString("warningSignQ25choice3"),rBundle.getString("warningSignQ25choice4")},
        {rBundle.getString("warningSignQ26choice1"),rBundle.getString("warningSignQ26choice2"),rBundle.getString("warningSignQ26choice3"),rBundle.getString("warningSignQ26choice4")},
        {rBundle.getString("warningSignQ27choice1"),rBundle.getString("warningSignQ27choice2"),rBundle.getString("warningSignQ27choice3"),rBundle.getString("warningSignQ27choice4")},
        {rBundle.getString("warningSignQ28choice1"),rBundle.getString("warningSignQ28choice2"),rBundle.getString("warningSignQ28choice3"),rBundle.getString("warningSignQ28choice4")},
        {rBundle.getString("warningSignQ29choice1"),rBundle.getString("warningSignQ29choice2"),rBundle.getString("warningSignQ29choice3"),rBundle.getString("warningSignQ29choice4")},
        {rBundle.getString("warningSignQ30choice1"),rBundle.getString("warningSignQ30choice2"),rBundle.getString("warningSignQ30choice3"),rBundle.getString("warningSignQ30choice4")},
        {rBundle.getString("warningSignQ31choice1"),rBundle.getString("warningSignQ31choice2"),rBundle.getString("warningSignQ31choice3"),rBundle.getString("warningSignQ31choice4")},
        {rBundle.getString("warningSignQ32choice1"),rBundle.getString("warningSignQ32choice2"),rBundle.getString("warningSignQ32choice3"),rBundle.getString("warningSignQ32choice4")}

    };
        
        
        choice1.setText(answers[x][0]);
        choice2.setText(answers[x][1]);
        choice3.setText(answers[x][2]);
        choice4.setText(answers[x][3]);
        
        nextQBtn.setText(rBundle.getString("nextQBtn"));
        scoreLabel.setText(rBundle.getString("scoreLabel") + " " + score);
        exitBtn.setText(rBundle.getString("exitBtn"));
        setTitle(rBundle.getString("examTitle") + " " + noOfQuestionsAsked);

        GregorianCalendar cal = new GregorianCalendar();
        DateFormat formatter = DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.FULL, loc);
        String date = formatter.format(cal.getTime());
        dateLabel.setText(date);
    }
    
    

    private void handleRandomGenerator() {//This method generates a random question at one time
        String answers[][] = {
        {rBundle.getString("infoSignQ1choice1"), rBundle.getString("infoSignQ1choice2"), rBundle.getString("infoSignQ1choice3"), rBundle.getString("infoSignQ1choice4")},
        {rBundle.getString("infoSignQ2choice1"), rBundle.getString("infoSignQ2choice2"), rBundle.getString("infoSignQ2choice3"), rBundle.getString("infoSignQ2choice4")},
        {rBundle.getString("infoSignQ3choice1"), rBundle.getString("infoSignQ3choice2"), rBundle.getString("infoSignQ3choice3"), rBundle.getString("infoSignQ3choice4")},
        {rBundle.getString("infoSignQ4choice1"), rBundle.getString("infoSignQ4choice2"), rBundle.getString("infoSignQ4choice3"), rBundle.getString("infoSignQ4choice4")},
        {rBundle.getString("infoSignQ5choice1"), rBundle.getString("infoSignQ5choice2"), rBundle.getString("infoSignQ5choice3"), rBundle.getString("infoSignQ5choice4")},
        {rBundle.getString("infoSignQ6choice1"), rBundle.getString("infoSignQ6choice2"), rBundle.getString("infoSignQ6choice3"), rBundle.getString("infoSignQ6choice4")},
        {rBundle.getString("infoSignQ7choice1"), rBundle.getString("infoSignQ7choice2"), rBundle.getString("infoSignQ7choice3"), rBundle.getString("infoSignQ7choice4")},
        {rBundle.getString("infoSignQ8choice1"), rBundle.getString("infoSignQ8choice2"), rBundle.getString("infoSignQ8choice3"), rBundle.getString("infoSignQ8choice4")},
        {rBundle.getString("infoSignQ9choice1"), rBundle.getString("infoSignQ9choice2"), rBundle.getString("infoSignQ9choice3"), rBundle.getString("infoSignQ9choice4")},
        {rBundle.getString("infoSignQ10choice1"), rBundle.getString("infoSignQ10choice2"), rBundle.getString("infoSignQ10choice3"), rBundle.getString("infoSignQ10choice4")},
        {rBundle.getString("infoSignQ11choice1"), rBundle.getString("infoSignQ11choice2"), rBundle.getString("infoSignQ11choice3"), rBundle.getString("infoSignQ11choice4")},
        {rBundle.getString("infoSignQ12choice1"), rBundle.getString("infoSignQ12choice2"), rBundle.getString("infoSignQ12choice3"), rBundle.getString("infoSignQ12choice4")},
        {rBundle.getString("infoSignQ13choice1"), rBundle.getString("infoSignQ13choice2"), rBundle.getString("infoSignQ13choice3"), rBundle.getString("infoSignQ13choice4")},
        {rBundle.getString("infoSignQ14choice1"), rBundle.getString("infoSignQ14choice2"), rBundle.getString("infoSignQ14choice3"), rBundle.getString("infoSignQ14choice4")},
        {rBundle.getString("infoSignQ15choice1"), rBundle.getString("infoSignQ15choice2"), rBundle.getString("infoSignQ15choice3"), rBundle.getString("infoSignQ15choice4")},
        {rBundle.getString("motorwaySignQ1choice1"), rBundle.getString("motorwaySignQ1choice2"), rBundle.getString("motorwaySignQ1choice3"), rBundle.getString("motorwaySignQ1choice4")},
        {rBundle.getString("motorwaySignQ2choice1"), rBundle.getString("motorwaySignQ2choice2"), rBundle.getString("motorwaySignQ2choice3"), rBundle.getString("motorwaySignQ2choice4")},
        {rBundle.getString("motorwaySignQ3choice1"), rBundle.getString("motorwaySignQ3choice2"), rBundle.getString("motorwaySignQ3choice3"), rBundle.getString("motorwaySignQ3choice4")},
        {rBundle.getString("motorwaySignQ4choice1"), rBundle.getString("motorwaySignQ4choice2"), rBundle.getString("motorwaySignQ4choice3"), rBundle.getString("motorwaySignQ4choice4")},
        {rBundle.getString("motorwaySignQ5choice1"), rBundle.getString("motorwaySignQ5choice2"), rBundle.getString("motorwaySignQ5choice3"), rBundle.getString("motorwaySignQ5choice4")},
        {rBundle.getString("motorwaySignQ6choice1"), rBundle.getString("motorwaySignQ6choice2"), rBundle.getString("motorwaySignQ6choice3"), rBundle.getString("motorwaySignQ6choice4")},
        {rBundle.getString("motorwaySignQ7choice1"), rBundle.getString("motorwaySignQ7choice2"), rBundle.getString("motorwaySignQ7choice3"), rBundle.getString("motorwaySignQ7choice4")},
        {rBundle.getString("motorwaySignQ8choice1"), rBundle.getString("motorwaySignQ8choice2"), rBundle.getString("motorwaySignQ8choice3"), rBundle.getString("motorwaySignQ8choice4")},
        {rBundle.getString("motorwaySignQ9choice1"), rBundle.getString("motorwaySignQ9choice2"), rBundle.getString("motorwaySignQ9choice3"), rBundle.getString("motorwaySignQ9choice4")},
        {rBundle.getString("motorwaySignQ10choice1"), rBundle.getString("motorwaySignQ10choice2"), rBundle.getString("motorwaySignQ10choice3"), rBundle.getString("motorwaySignQ10choice4")},
        {rBundle.getString("regulatoryTrafficSignQ1choice1"), rBundle.getString("regulatoryTrafficSignQ1choice2"), rBundle.getString("regulatoryTrafficSignQ1choice3"), rBundle.getString("regulatoryTrafficSignQ1choice4")},
        {rBundle.getString("regulatoryTrafficSignQ2choice1"), rBundle.getString("regulatoryTrafficSignQ2choice2"), rBundle.getString("regulatoryTrafficSignQ2choice3"), rBundle.getString("regulatoryTrafficSignQ2choice4")},
        {rBundle.getString("regulatoryTrafficSignQ3choice1"), rBundle.getString("regulatoryTrafficSignQ3choice2"), rBundle.getString("regulatoryTrafficSignQ3choice3"), rBundle.getString("regulatoryTrafficSignQ3choice4")},
        {rBundle.getString("regulatoryTrafficSignQ4choice1"), rBundle.getString("regulatoryTrafficSignQ4choice2"), rBundle.getString("regulatoryTrafficSignQ4choice3"), rBundle.getString("regulatoryTrafficSignQ4choice4")},
        {rBundle.getString("regulatoryTrafficSignQ5choice1"), rBundle.getString("regulatoryTrafficSignQ5choice2"), rBundle.getString("regulatoryTrafficSignQ5choice3"), rBundle.getString("regulatoryTrafficSignQ5choice4")},
        {rBundle.getString("regulatoryTrafficSignQ6choice1"), rBundle.getString("regulatoryTrafficSignQ6choice2"), rBundle.getString("regulatoryTrafficSignQ6choice3"), rBundle.getString("regulatoryTrafficSignQ6choice4")},
        {rBundle.getString("regulatoryTrafficSignQ7choice1"), rBundle.getString("regulatoryTrafficSignQ7choice2"), rBundle.getString("regulatoryTrafficSignQ7choice3"), rBundle.getString("regulatoryTrafficSignQ7choice4")},
        {rBundle.getString("regulatoryTrafficSignQ8choice1"), rBundle.getString("regulatoryTrafficSignQ8choice2"), rBundle.getString("regulatoryTrafficSignQ8choice3"), rBundle.getString("regulatoryTrafficSignQ8choice4")},
        {rBundle.getString("regulatoryTrafficSignQ9choice1"), rBundle.getString("regulatoryTrafficSignQ9choice2"), rBundle.getString("regulatoryTrafficSignQ9choice3"), rBundle.getString("regulatoryTrafficSignQ9choice4")},
        {rBundle.getString("regulatoryTrafficSignQ10choice1"), rBundle.getString("regulatoryTrafficSignQ10choice2"), rBundle.getString("regulatoryTrafficSignQ10choice3"), rBundle.getString("regulatoryTrafficSignQ10choice4")},
        {rBundle.getString("regulatoryTrafficSignQ11choice1"), rBundle.getString("regulatoryTrafficSignQ11choice2"), rBundle.getString("regulatoryTrafficSignQ11choice3"), rBundle.getString("regulatoryTrafficSignQ11choice4")},
        {rBundle.getString("regulatoryTrafficSignQ12choice1"), rBundle.getString("regulatoryTrafficSignQ12choice2"), rBundle.getString("regulatoryTrafficSignQ12choice3"), rBundle.getString("regulatoryTrafficSignQ12choice4")},
        {rBundle.getString("regulatoryTrafficSignQ13choice1"), rBundle.getString("regulatoryTrafficSignQ13choice2"), rBundle.getString("regulatoryTrafficSignQ13choice3"), rBundle.getString("regulatoryTrafficSignQ13choice4")},
        {rBundle.getString("regulatoryTrafficSignQ14choice1"), rBundle.getString("regulatoryTrafficSignQ14choice2"), rBundle.getString("regulatoryTrafficSignQ14choice3"), rBundle.getString("regulatoryTrafficSignQ14choice4")},
        {rBundle.getString("regulatoryTrafficSignQ15choice1"), rBundle.getString("regulatoryTrafficSignQ15choice2"), rBundle.getString("regulatoryTrafficSignQ15choice3"), rBundle.getString("regulatoryTrafficSignQ15choice4")},
        {rBundle.getString("regulatoryTrafficSignQ16choice1"), rBundle.getString("regulatoryTrafficSignQ16choice2"), rBundle.getString("regulatoryTrafficSignQ16choice3"), rBundle.getString("regulatoryTrafficSignQ16choice4")},
        {rBundle.getString("regulatoryTrafficSignQ17choice1"), rBundle.getString("regulatoryTrafficSignQ17choice2"), rBundle.getString("regulatoryTrafficSignQ17choice3"), rBundle.getString("regulatoryTrafficSignQ17choice4")},
        {rBundle.getString("regulatoryTrafficSignQ18choice1"), rBundle.getString("regulatoryTrafficSignQ18choice2"), rBundle.getString("regulatoryTrafficSignQ18choice3"), rBundle.getString("regulatoryTrafficSignQ18choice4")},
        {rBundle.getString("regulatoryTrafficSignQ19choice1"), rBundle.getString("regulatoryTrafficSignQ19choice2"), rBundle.getString("regulatoryTrafficSignQ19choice3"), rBundle.getString("regulatoryTrafficSignQ19choice4")},
        {rBundle.getString("regulatoryTrafficSignQ20choice1"), rBundle.getString("regulatoryTrafficSignQ20choice2"), rBundle.getString("regulatoryTrafficSignQ20choice3"), rBundle.getString("regulatoryTrafficSignQ20choice4")},
        {rBundle.getString("regulatoryTrafficSignQ21choice1"), rBundle.getString("regulatoryTrafficSignQ21choice2"), rBundle.getString("regulatoryTrafficSignQ21choice3"), rBundle.getString("regulatoryTrafficSignQ21choice4")},
        {rBundle.getString("regulatoryTrafficSignQ22choice1"), rBundle.getString("regulatoryTrafficSignQ22choice2"), rBundle.getString("regulatoryTrafficSignQ22choice3"), rBundle.getString("regulatoryTrafficSignQ22choice4")},
        {rBundle.getString("regulatoryTrafficSignQ23choice1"), rBundle.getString("regulatoryTrafficSignQ23choice2"), rBundle.getString("regulatoryTrafficSignQ23choice3"), rBundle.getString("regulatoryTrafficSignQ23choice4")},
        {rBundle.getString("regulatoryTrafficSignQ24choice1"), rBundle.getString("regulatoryTrafficSignQ24choice2"), rBundle.getString("regulatoryTrafficSignQ24choice3"), rBundle.getString("regulatoryTrafficSignQ24choice4")},
        {rBundle.getString("regulatoryTrafficSignQ25choice1"), rBundle.getString("regulatoryTrafficSignQ25choice2"), rBundle.getString("regulatoryTrafficSignQ25choice3"), rBundle.getString("regulatoryTrafficSignQ25choice4")},
        {rBundle.getString("regulatoryTrafficSignQ26choice1"), rBundle.getString("regulatoryTrafficSignQ26choice2"), rBundle.getString("regulatoryTrafficSignQ26choice3"), rBundle.getString("regulatoryTrafficSignQ26choice4")},
        {rBundle.getString("regulatoryTrafficSignQ27choice1"), rBundle.getString("regulatoryTrafficSignQ27choice2"), rBundle.getString("regulatoryTrafficSignQ27choice3"), rBundle.getString("regulatoryTrafficSignQ27choice4")},
        {rBundle.getString("regulatoryTrafficSignQ28choice1"), rBundle.getString("regulatoryTrafficSignQ28choice2"), rBundle.getString("regulatoryTrafficSignQ28choice3"), rBundle.getString("regulatoryTrafficSignQ28choice4")},
        {rBundle.getString("regulatoryTrafficSignQ29choice1"), rBundle.getString("regulatoryTrafficSignQ29choice2"), rBundle.getString("regulatoryTrafficSignQ29choice3"), rBundle.getString("regulatoryTrafficSignQ29choice4")},
        {rBundle.getString("regulatoryTrafficSignQ30choice1"), rBundle.getString("regulatoryTrafficSignQ30choice2"), rBundle.getString("regulatoryTrafficSignQ30choice3"), rBundle.getString("regulatoryTrafficSignQ30choice4")},
        {rBundle.getString("regulatoryTrafficSignQ31choice1"), rBundle.getString("regulatoryTrafficSignQ31choice2"), rBundle.getString("regulatoryTrafficSignQ31choice3"), rBundle.getString("regulatoryTrafficSignQ31choice4")},
        {rBundle.getString("touristSignQ1choice1"),rBundle.getString("touristSignQ1choice2"),rBundle.getString("touristSignQ1choice3"),rBundle.getString("touristSignQ1choice4")},
        {rBundle.getString("touristSignQ2choice1"),rBundle.getString("touristSignQ2choice2"),rBundle.getString("touristSignQ2choice3"),rBundle.getString("touristSignQ2choice4")},
        {rBundle.getString("touristSignQ3choice1"),rBundle.getString("touristSignQ3choice2"),rBundle.getString("touristSignQ3choice3"),rBundle.getString("touristSignQ3choice4")},
        {rBundle.getString("touristSignQ4choice1"),rBundle.getString("touristSignQ4choice2"),rBundle.getString("touristSignQ4choice3"),rBundle.getString("touristSignQ4choice4")},
        {rBundle.getString("touristSignQ5choice1"),rBundle.getString("touristSignQ5choice2"),rBundle.getString("touristSignQ5choice3"),rBundle.getString("touristSignQ5choice4")},
        {rBundle.getString("touristSignQ6choice1"),rBundle.getString("touristSignQ6choice2"),rBundle.getString("touristSignQ6choice3"),rBundle.getString("touristSignQ6choice4")},
        {rBundle.getString("touristSignQ7choice1"),rBundle.getString("touristSignQ7choice2"),rBundle.getString("touristSignQ7choice3"),rBundle.getString("touristSignQ7choice4")},
        {rBundle.getString("touristSignQ8choice1"),rBundle.getString("touristSignQ8choice2"),rBundle.getString("touristSignQ8choice3"),rBundle.getString("touristSignQ8choice4")},
        {rBundle.getString("warningSignQ1choice1"),rBundle.getString("warningSignQ1choice2"),rBundle.getString("warningSignQ1choice3"),rBundle.getString("warningSignQ1choice4")},
        {rBundle.getString("warningSignQ2choice1"),rBundle.getString("warningSignQ2choice2"),rBundle.getString("warningSignQ2choice3"),rBundle.getString("warningSignQ2choice4")},
        {rBundle.getString("warningSignQ3choice1"),rBundle.getString("warningSignQ3choice2"),rBundle.getString("warningSignQ3choice3"),rBundle.getString("warningSignQ3choice4")},
        {rBundle.getString("warningSignQ4choice1"),rBundle.getString("warningSignQ4choice2"),rBundle.getString("warningSignQ4choice3"),rBundle.getString("warningSignQ4choice4")},
        {rBundle.getString("warningSignQ5choice1"),rBundle.getString("warningSignQ5choice2"),rBundle.getString("warningSignQ5choice3"),rBundle.getString("warningSignQ5choice4")},
        {rBundle.getString("warningSignQ6choice1"),rBundle.getString("warningSignQ6choice2"),rBundle.getString("warningSignQ6choice3"),rBundle.getString("warningSignQ6choice4")},
        {rBundle.getString("warningSignQ7choice1"),rBundle.getString("warningSignQ7choice2"),rBundle.getString("warningSignQ7choice3"),rBundle.getString("warningSignQ7choice4")},
        {rBundle.getString("warningSignQ8choice1"),rBundle.getString("warningSignQ8choice2"),rBundle.getString("warningSignQ8choice3"),rBundle.getString("warningSignQ8choice4")},
        {rBundle.getString("warningSignQ9choice1"),rBundle.getString("warningSignQ9choice2"),rBundle.getString("warningSignQ9choice3"),rBundle.getString("warningSignQ9choice4")},
        {rBundle.getString("warningSignQ10choice1"),rBundle.getString("warningSignQ10choice2"),rBundle.getString("warningSignQ10choice3"),rBundle.getString("warningSignQ10choice4")},
        {rBundle.getString("warningSignQ11choice1"),rBundle.getString("warningSignQ11choice2"),rBundle.getString("warningSignQ11choice3"),rBundle.getString("warningSignQ11choice4")},
        {rBundle.getString("warningSignQ12choice1"),rBundle.getString("warningSignQ12choice2"),rBundle.getString("warningSignQ12choice3"),rBundle.getString("warningSignQ12choice4")},
        {rBundle.getString("warningSignQ13choice1"),rBundle.getString("warningSignQ13choice2"),rBundle.getString("warningSignQ13choice3"),rBundle.getString("warningSignQ13choice4")},
        {rBundle.getString("warningSignQ14choice1"),rBundle.getString("warningSignQ14choice2"),rBundle.getString("warningSignQ14choice3"),rBundle.getString("warningSignQ14choice4")},
        {rBundle.getString("warningSignQ15choice1"),rBundle.getString("warningSignQ15choice2"),rBundle.getString("warningSignQ15choice3"),rBundle.getString("warningSignQ15choice4")},
        {rBundle.getString("warningSignQ16choice1"),rBundle.getString("warningSignQ16choice2"),rBundle.getString("warningSignQ16choice3"),rBundle.getString("warningSignQ16choice4")},
        {rBundle.getString("warningSignQ17choice1"),rBundle.getString("warningSignQ17choice2"),rBundle.getString("warningSignQ17choice3"),rBundle.getString("warningSignQ17choice4")},
        {rBundle.getString("warningSignQ18choice1"),rBundle.getString("warningSignQ18choice2"),rBundle.getString("warningSignQ18choice3"),rBundle.getString("warningSignQ18choice4")},
        {rBundle.getString("warningSignQ19choice1"),rBundle.getString("warningSignQ19choice2"),rBundle.getString("warningSignQ19choice3"),rBundle.getString("warningSignQ19choice4")},
        {rBundle.getString("warningSignQ20choice1"),rBundle.getString("warningSignQ20choice2"),rBundle.getString("warningSignQ20choice3"),rBundle.getString("warningSignQ20choice4")},
        {rBundle.getString("warningSignQ21choice1"),rBundle.getString("warningSignQ21choice2"),rBundle.getString("warningSignQ21choice3"),rBundle.getString("warningSignQ21choice4")},
        {rBundle.getString("warningSignQ22choice1"),rBundle.getString("warningSignQ22choice2"),rBundle.getString("warningSignQ22choice3"),rBundle.getString("warningSignQ22choice4")},
        {rBundle.getString("warningSignQ23choice1"),rBundle.getString("warningSignQ23choice2"),rBundle.getString("warningSignQ23choice3"),rBundle.getString("warningSignQ23choice4")},
        {rBundle.getString("warningSignQ24choice1"),rBundle.getString("warningSignQ24choice2"),rBundle.getString("warningSignQ24choice3"),rBundle.getString("warningSignQ24choice4")},
        {rBundle.getString("warningSignQ25choice1"),rBundle.getString("warningSignQ25choice2"),rBundle.getString("warningSignQ25choice3"),rBundle.getString("warningSignQ25choice4")},
        {rBundle.getString("warningSignQ26choice1"),rBundle.getString("warningSignQ26choice2"),rBundle.getString("warningSignQ26choice3"),rBundle.getString("warningSignQ26choice4")},
        {rBundle.getString("warningSignQ27choice1"),rBundle.getString("warningSignQ27choice2"),rBundle.getString("warningSignQ27choice3"),rBundle.getString("warningSignQ27choice4")},
        {rBundle.getString("warningSignQ28choice1"),rBundle.getString("warningSignQ28choice2"),rBundle.getString("warningSignQ28choice3"),rBundle.getString("warningSignQ28choice4")},
        {rBundle.getString("warningSignQ29choice1"),rBundle.getString("warningSignQ29choice2"),rBundle.getString("warningSignQ29choice3"),rBundle.getString("warningSignQ29choice4")},
        {rBundle.getString("warningSignQ30choice1"),rBundle.getString("warningSignQ30choice2"),rBundle.getString("warningSignQ30choice3"),rBundle.getString("warningSignQ30choice4")},
        {rBundle.getString("warningSignQ31choice1"),rBundle.getString("warningSignQ31choice2"),rBundle.getString("warningSignQ31choice3"),rBundle.getString("warningSignQ31choice4")},
        {rBundle.getString("warningSignQ32choice1"),rBundle.getString("warningSignQ32choice2"),rBundle.getString("warningSignQ32choice3"),rBundle.getString("warningSignQ32choice4")}

    };
        try{
            x = (int) Math.floor(Math.random() * answers.length);//This randomly generates questions
            
           while(asked.contains(x)){
               
            x = (int) Math.floor(Math.random() * answers.length);
            
            }
            
                asked.add(x);//Adds the asked questions into the asked ArrayList so that the same questions will not generate multiple times
            
        

        String pics = imageNames[x];
        imgLabel.setIcon(new ImageIcon(getClass().getResource("/images/All Signs/" + pics)));//Fetches the relevant images from the specified directory
      
        choice1.setText("" + answers[x][0]); /* Displays the relevant answers on those 4 radio buttons */
        choice2.setText("" + answers[x][1]);
        choice3.setText("" + answers[x][2]);
        choice4.setText("" + answers[x][3]);            
        

        if (noOfQuestionsAsked == 40) {
            nextQBtn.setText(rBundle.getString("finishBtn"));//Finish button appears on the final question

        }

        if (noOfQuestionsAsked == 41) {//After 40 questions are answered
            this.setVisible(false);//Finishes the test
            feedback.iniScore(score);//Pushes the total score to the feedback JFrame
            feedback.totalWrongAnswers(incorrectAnswers);//Pushes the total no of wrong answers to the feedback JFrame
            feedback.setVisible(true);//Feedback JFrame becomes visible
             String query = "INSERT INTO roadtestscores(username, score)VALUES('"+candidateNameLabel.getText()+"','"+scoreLabel.getText()+"')";
             executeSQLQuery(query, "");

        }
        }catch(NullPointerException | ArrayIndexOutOfBoundsException e){//Catches all possible exceptions
        }
    }

    public void iniScore(int a) {
        score = a;
       
    }
    
     public void totalWrongAnswers(int b) {
        incorrectAnswers = b;
        
    }
    

    public String getSelectedButtonText(ButtonGroup buttonGroup) {//This method will loop through the 4 radio buttons to check if the user selected a correct or an incorrect answer when this method is called
        for (Enumeration<AbstractButton> buttons = buttonGroup.getElements(); buttons.hasMoreElements();) {
            AbstractButton button = buttons.nextElement();

            if (button.isSelected()) {
                return button.getText();
            }
        }

        return null;
    }
    
   

    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QuizTest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QuizTest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QuizTest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QuizTest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new QuizTest().setVisible(false);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup answerButtons;
    private javax.swing.JLabel candidateNameLabel;
    private javax.swing.JRadioButton choice1;
    private javax.swing.JRadioButton choice2;
    private javax.swing.JRadioButton choice3;
    private javax.swing.JRadioButton choice4;
    private javax.swing.JLabel chooseLangLabel;
    private javax.swing.JLabel dateLabel;
    private javax.swing.JButton englishBtn;
    private javax.swing.JButton exitBtn;
    private javax.swing.JLabel imgLabel;
    private javax.swing.JButton japaneseBtn;
    private javax.swing.JButton nextQBtn;
    private javax.swing.JLabel questionLabel;
    private javax.swing.JLabel scoreLabel;
    private javax.swing.JButton spanishBtn;
    // End of variables declaration//GEN-END:variables

}
